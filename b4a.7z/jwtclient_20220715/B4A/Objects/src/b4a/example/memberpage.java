package b4a.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class memberpage extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example.memberpage");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example.memberpage.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4a.example3.customlistview _clvdata = null;
public b4a.example.preferencesdialog _prefdialog = null;
public b4a.example.ddd _dd = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblmem_no = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblmem_name = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblmem_password = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblmem_memo = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbledit = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbldelete = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _label1 = null;
public b4a.example.dateutils _dateutils = null;
public b4a.example.main _main = null;
public b4a.example.starter _starter = null;
public b4a.example.function01 _function01 = null;
public b4a.example.b4xpages _b4xpages = null;
public b4a.example.b4xcollections _b4xcollections = null;
public b4a.example.httputils2service _httputils2service = null;
public b4a.example.xuiviewsutils _xuiviewsutils = null;
public void  _adddata() throws Exception{
ResumableSub_AddData rsub = new ResumableSub_AddData(this);
rsub.resume(ba, null);
}
public static class ResumableSub_AddData extends BA.ResumableSub {
public ResumableSub_AddData(b4a.example.memberpage parent) {
this.parent = parent;
}
b4a.example.memberpage parent;
anywheresoftware.b4a.objects.collections.Map _item = null;
int _result = 0;
anywheresoftware.b4a.objects.StringUtils _su = null;
String _basicauth = "";
String _authinfo = "";
b4a.example.httpjob _job = null;
anywheresoftware.b4a.objects.collections.Map _m1 = null;
anywheresoftware.b4a.objects.collections.JSONParser.JSONGenerator _jg = null;
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _m = null;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 208;BA.debugLine="Dim Item As Map = CreateMap()";
_item = new anywheresoftware.b4a.objects.collections.Map();
_item = parent.__c.createMap(new Object[] {});
 //BA.debugLineNum = 210;BA.debugLine="PrefDialog.Title = \"會員資料-新增\"";
parent._prefdialog._settitle /*Object*/ ((Object)("會員資料-新增"));
 //BA.debugLineNum = 211;BA.debugLine="PrefDialog.LoadFromJson(File.ReadString(File.DirA";
parent._prefdialog._loadfromjson /*String*/ (parent.__c.File.ReadString(parent.__c.File.getDirAssets(),"template.json"));
 //BA.debugLineNum = 213;BA.debugLine="Wait For (PrefDialog.ShowDialog(Item, \"OK\", \"CANC";
parent.__c.WaitFor("complete", ba, this, parent._prefdialog._showdialog /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_item,(Object)("OK"),(Object)("CANCEL")));
this.state = 17;
return;
case 17:
//C
this.state = 1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 214;BA.debugLine="If Result = xui.DialogResponse_Positive Then";
if (true) break;

case 1:
//if
this.state = 16;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 216;BA.debugLine="Log(\"遠端新增...\")";
parent.__c.LogImpl("43473418","遠端新增...",0);
 //BA.debugLineNum = 217;BA.debugLine="Dim su As StringUtils";
_su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 218;BA.debugLine="Dim basicAuth,authInfo As String";
_basicauth = "";
_authinfo = "";
 //BA.debugLineNum = 219;BA.debugLine="Dim job As HttpJob";
_job = new b4a.example.httpjob();
 //BA.debugLineNum = 222;BA.debugLine="basicAuth = Starter.token";
_basicauth = parent._starter._token /*String*/ ;
 //BA.debugLineNum = 223;BA.debugLine="authInfo = su.EncodeBase64(basicAuth.GetBytes(\"U";
_authinfo = _su.EncodeBase64(_basicauth.getBytes("UTF8"));
 //BA.debugLineNum = 225;BA.debugLine="Log($\"basicAuth= Bearer ${su.EncodeBase64(basicA";
parent.__c.LogImpl("43473427",("basicAuth= Bearer "+parent.__c.SmartStringFormatter("",(Object)(_su.EncodeBase64(_basicauth.getBytes("UTF8"))))+""),0);
 //BA.debugLineNum = 227;BA.debugLine="Dim m1 As Map";
_m1 = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 228;BA.debugLine="m1.Initialize";
_m1.Initialize();
 //BA.debugLineNum = 229;BA.debugLine="m1.Put(\"action\",\"insert\")";
_m1.Put((Object)("action"),(Object)("insert"));
 //BA.debugLineNum = 230;BA.debugLine="m1.Put(\"mem_no\",Item.Get(\"mem_no\"))";
_m1.Put((Object)("mem_no"),_item.Get((Object)("mem_no")));
 //BA.debugLineNum = 231;BA.debugLine="m1.Put(\"mem_name\",Item.Get(\"mem_name\"))";
_m1.Put((Object)("mem_name"),_item.Get((Object)("mem_name")));
 //BA.debugLineNum = 232;BA.debugLine="m1.Put(\"mem_password\",Item.Get(\"mem_password\"))";
_m1.Put((Object)("mem_password"),_item.Get((Object)("mem_password")));
 //BA.debugLineNum = 233;BA.debugLine="m1.Put(\"mem_memo\",Item.Get(\"mem_memo\"))";
_m1.Put((Object)("mem_memo"),_item.Get((Object)("mem_memo")));
 //BA.debugLineNum = 235;BA.debugLine="Dim jg As JSONGenerator";
_jg = new anywheresoftware.b4a.objects.collections.JSONParser.JSONGenerator();
 //BA.debugLineNum = 236;BA.debugLine="jg.Initialize(m1)";
_jg.Initialize(_m1);
 //BA.debugLineNum = 237;BA.debugLine="jg.ToString";
_jg.ToString();
 //BA.debugLineNum = 239;BA.debugLine="job.Initialize(\"\",Me)";
_job._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 240;BA.debugLine="job.PostString($\"https://${Main.url}/ex02/ss_mem";
_job._poststring /*String*/ (("https://"+parent.__c.SmartStringFormatter("",(Object)(parent._main._url /*String*/ ))+"/ex02/ss_member"),("json="+parent.__c.SmartStringFormatter("",(Object)(_jg.ToString()))+""));
 //BA.debugLineNum = 241;BA.debugLine="job.GetRequest.SetHeader(\"Authorization\", \"Beare";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetHeader("Authorization","Bearer "+_authinfo);
 //BA.debugLineNum = 242;BA.debugLine="job.GetRequest.SetContentType(\"application/x-www";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetContentType("application/x-www-form-urlencoded");
 //BA.debugLineNum = 244;BA.debugLine="ProgressDialogShow(\"Connecting to server...\")";
parent.__c.ProgressDialogShow(ba,BA.ObjectToCharSequence("Connecting to server..."));
 //BA.debugLineNum = 245;BA.debugLine="Wait For (job) JobDone(job As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_job));
this.state = 18;
return;
case 18:
//C
this.state = 4;
_job = (b4a.example.httpjob) result[0];
;
 //BA.debugLineNum = 246;BA.debugLine="ProgressDialogHide";
parent.__c.ProgressDialogHide();
 //BA.debugLineNum = 247;BA.debugLine="Log(\"Result JobDone: \" & job.Success)";
parent.__c.LogImpl("43473449","Result JobDone: "+BA.ObjectToString(_job._success /*boolean*/ ),0);
 //BA.debugLineNum = 248;BA.debugLine="If job.Success Then";
if (true) break;

case 4:
//if
this.state = 15;
if (_job._success /*boolean*/ ) { 
this.state = 6;
}else {
this.state = 14;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 249;BA.debugLine="Log(\"Server回應 \"&job.GetString)";
parent.__c.LogImpl("43473451","Server回應 "+_job._getstring /*String*/ (),0);
 //BA.debugLineNum = 250;BA.debugLine="Dim parser As JSONParser";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 251;BA.debugLine="parser.Initialize(job.GetString)";
_parser.Initialize(_job._getstring /*String*/ ());
 //BA.debugLineNum = 252;BA.debugLine="Dim m As Map = parser.NextObject";
_m = new anywheresoftware.b4a.objects.collections.Map();
_m = _parser.NextObject();
 //BA.debugLineNum = 253;BA.debugLine="If m.Get(\"success\") = \"0\" Then";
if (true) break;

case 7:
//if
this.state = 12;
if ((_m.Get((Object)("success"))).equals((Object)("0"))) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 254;BA.debugLine="Log(m.Get(\"message\"))";
parent.__c.LogImpl("43473456",BA.ObjectToString(_m.Get((Object)("message"))),0);
 //BA.debugLineNum = 256;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast";
parent._function01._showtoast /*String*/ (ba,parent._b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._toast /*b4a.example.bctoast*/ ,parent._root,BA.ObjectToString(_m.Get((Object)("message"))));
 //BA.debugLineNum = 258;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 260;BA.debugLine="Log(m.Get(\"message\"))";
parent.__c.LogImpl("43473462",BA.ObjectToString(_m.Get((Object)("message"))),0);
 if (true) break;

case 12:
//C
this.state = 15;
;
 if (true) break;

case 14:
//C
this.state = 15;
 //BA.debugLineNum = 263;BA.debugLine="Log(job.ErrorMessage)";
parent.__c.LogImpl("43473465",_job._errormessage /*String*/ ,0);
 //BA.debugLineNum = 264;BA.debugLine="xui.MsgboxAsync(job.ErrorMessage, \"Error\")";
parent._xui.MsgboxAsync(ba,BA.ObjectToCharSequence(_job._errormessage /*String*/ ),BA.ObjectToCharSequence("Error"));
 //BA.debugLineNum = 266;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 15:
//C
this.state = 16;
;
 //BA.debugLineNum = 271;BA.debugLine="Log(\"本地新增...\")";
parent.__c.LogImpl("43473473","本地新增...",0);
 //BA.debugLineNum = 272;BA.debugLine="Dim p As B4XView = CreateCard(m1)";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._createcard(_m1);
 //BA.debugLineNum = 273;BA.debugLine="clvData.Add(p, m1)";
parent._clvdata._add(_p,(Object)(_m1.getObject()));
 //BA.debugLineNum = 275;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast ,";
parent._function01._showtoast /*String*/ (ba,parent._b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._toast /*b4a.example.bctoast*/ ,parent._root,"新增成功!!");
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 278;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public void  _jobdone(b4a.example.httpjob _job) throws Exception{
}
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
anywheresoftware.b4a.objects.CSBuilder _cs = null;
b4a.example.b4xpagesmanager._b4amenuitem _mi = null;
 //BA.debugLineNum = 26;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 29;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 33;BA.debugLine="dd.Initialize";
_dd._initialize /*String*/ (ba);
 //BA.debugLineNum = 34;BA.debugLine="xui.RegisterDesignerClass(dd)";
_xui.RegisterDesignerClass((Object)(_dd));
 //BA.debugLineNum = 40;BA.debugLine="Root.LoadLayout(\"MemberPage\")";
_root.LoadLayout("MemberPage",ba);
 //BA.debugLineNum = 41;BA.debugLine="B4XPages.SetTitle(Me, \"會員資料\")";
_b4xpages._settitle /*String*/ (ba,this,(Object)("會員資料"));
 //BA.debugLineNum = 44;BA.debugLine="Dim cs As CSBuilder";
_cs = new anywheresoftware.b4a.objects.CSBuilder();
 //BA.debugLineNum = 45;BA.debugLine="Dim mi As B4AMenuItem";
_mi = new b4a.example.b4xpagesmanager._b4amenuitem();
 //BA.debugLineNum = 46;BA.debugLine="mi = B4XPages.AddMenuItem(Me, cs.Initialize.Typef";
_mi = _b4xpages._addmenuitem /*b4a.example.b4xpagesmanager._b4amenuitem*/ (ba,this,(Object)(_cs.Initialize().Typeface(__c.Typeface.getFONTAWESOME()).Size((int) (22)).Append(BA.ObjectToCharSequence(_b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._pluschar /*String*/ )).PopAll().getObject()));
 //BA.debugLineNum = 47;BA.debugLine="mi.AddToBar = True";
_mi.AddToBar /*boolean*/  = __c.True;
 //BA.debugLineNum = 48;BA.debugLine="mi.Tag = \"Add Event\"";
_mi.Tag /*String*/  = "Add Event";
 //BA.debugLineNum = 49;BA.debugLine="mi = B4XPages.AddMenuItem(Me, cs.Initialize.Typef";
_mi = _b4xpages._addmenuitem /*b4a.example.b4xpagesmanager._b4amenuitem*/ (ba,this,(Object)(_cs.Initialize().Typeface(__c.Typeface.getFONTAWESOME()).Size((int) (22)).Append(BA.ObjectToCharSequence(__c.Chr(((int)0xf0e2)))).PopAll().getObject()));
 //BA.debugLineNum = 50;BA.debugLine="mi.AddToBar = True";
_mi.AddToBar /*boolean*/  = __c.True;
 //BA.debugLineNum = 51;BA.debugLine="mi.Tag = \"Refresh Event\"";
_mi.Tag /*String*/  = "Refresh Event";
 //BA.debugLineNum = 52;BA.debugLine="B4XPages.AddMenuItem(Me,\"mnu2\")";
_b4xpages._addmenuitem /*b4a.example.b4xpagesmanager._b4amenuitem*/ (ba,this,(Object)("mnu2"));
 //BA.debugLineNum = 55;BA.debugLine="PrefDialog.Initialize(Root, \"編輯\", 300dip , 400dip";
_prefdialog._initialize /*String*/ (ba,_root,(Object)("編輯"),__c.DipToCurrent((int) (300)),__c.DipToCurrent((int) (400)));
 //BA.debugLineNum = 59;BA.debugLine="PrefDialog.SetEventsListener(Me, \"PrefDialog\")";
_prefdialog._seteventslistener /*String*/ (this,"PrefDialog");
 //BA.debugLineNum = 63;BA.debugLine="QueryData";
_querydata();
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_menuclick(String _tag) throws Exception{
 //BA.debugLineNum = 75;BA.debugLine="Sub B4XPage_MenuClick (Tag As String)";
 //BA.debugLineNum = 76;BA.debugLine="Log(\"B4XPage_MenuClick==>\")";
__c.LogImpl("43276801","B4XPage_MenuClick==>",0);
 //BA.debugLineNum = 77;BA.debugLine="Log(Tag)";
__c.LogImpl("43276802",_tag,0);
 //BA.debugLineNum = 79;BA.debugLine="If Tag = \"Add Event\" Then";
if ((_tag).equals("Add Event")) { 
 //BA.debugLineNum = 80;BA.debugLine="Log(\"Add Event\")";
__c.LogImpl("43276805","Add Event",0);
 //BA.debugLineNum = 82;BA.debugLine="AddData";
_adddata();
 };
 //BA.debugLineNum = 84;BA.debugLine="If Tag = \"Refresh Event\" Then";
if ((_tag).equals("Refresh Event")) { 
 //BA.debugLineNum = 85;BA.debugLine="Log(\"Refresh Event\")";
__c.LogImpl("43276810","Refresh Event",0);
 //BA.debugLineNum = 87;BA.debugLine="QueryData";
_querydata();
 };
 //BA.debugLineNum = 89;BA.debugLine="If Tag = \"mnu2\" Then";
if ((_tag).equals("mnu2")) { 
 //BA.debugLineNum = 90;BA.debugLine="Log(\"mnu2\")";
__c.LogImpl("43276815","mnu2",0);
 //BA.debugLineNum = 93;BA.debugLine="Function01.ShowToast ( B4XPages.MainPage.toast ,";
_function01._showtoast /*String*/ (ba,_b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._toast /*b4a.example.bctoast*/ ,_root,"mnu2");
 };
 //BA.debugLineNum = 97;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_resize(int _width,int _height) throws Exception{
 //BA.debugLineNum = 67;BA.debugLine="Sub B4XPage_Resize (Width As Int, Height As Int)";
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Private Root As B4XView 'ignore";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 3;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 6;BA.debugLine="Private clvData As CustomListView";
_clvdata = new b4a.example3.customlistview();
 //BA.debugLineNum = 7;BA.debugLine="Public PrefDialog As PreferencesDialog";
_prefdialog = new b4a.example.preferencesdialog();
 //BA.debugLineNum = 8;BA.debugLine="Private dd As DDD";
_dd = new b4a.example.ddd();
 //BA.debugLineNum = 11;BA.debugLine="Private lblMem_No As B4XView";
_lblmem_no = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Private lblMem_Name As B4XView";
_lblmem_name = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private lblMem_Password As B4XView";
_lblmem_password = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private lblMem_Memo As B4XView";
_lblmem_memo = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Private lblEdit As B4XView";
_lbledit = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private lblDelete As B4XView";
_lbldelete = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 17;BA.debugLine="Private Label1 As B4XView";
_label1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.B4XViewWrapper  _createcard(anywheresoftware.b4a.objects.collections.Map _data) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
int _height = 0;
 //BA.debugLineNum = 100;BA.debugLine="Sub CreateCard (Data As Map) As B4XView";
 //BA.debugLineNum = 101;BA.debugLine="Dim p As B4XView = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 102;BA.debugLine="Dim height As Int = 220dip";
_height = __c.DipToCurrent((int) (220));
 //BA.debugLineNum = 104;BA.debugLine="height = clvData.AsView.Height /3 -2dip";
_height = (int) (_clvdata._asview().getHeight()/(double)3-__c.DipToCurrent((int) (2)));
 //BA.debugLineNum = 107;BA.debugLine="If GetDeviceLayoutValues.ApproximateScreenSize <";
if (__c.GetDeviceLayoutValues(ba).getApproximateScreenSize()<4.5) { 
_height = __c.DipToCurrent((int) (310));};
 //BA.debugLineNum = 109;BA.debugLine="Log(\"ApproximateScreenSize= \"&GetDeviceLayoutValu";
__c.LogImpl("43342345","ApproximateScreenSize= "+BA.NumberToString(__c.GetDeviceLayoutValues(ba).getApproximateScreenSize()),0);
 //BA.debugLineNum = 112;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, clvData.AsView.Width";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),_clvdata._asview().getWidth(),_height);
 //BA.debugLineNum = 113;BA.debugLine="p.LoadLayout(\"Card\")";
_p.LoadLayout("Card",ba);
 //BA.debugLineNum = 116;BA.debugLine="lblMem_No.Text = Data.Get(\"mem_no\")";
_lblmem_no.setText(BA.ObjectToCharSequence(_data.Get((Object)("mem_no"))));
 //BA.debugLineNum = 117;BA.debugLine="lblMem_Name.Text = Data.Get(\"mem_name\")";
_lblmem_name.setText(BA.ObjectToCharSequence(_data.Get((Object)("mem_name"))));
 //BA.debugLineNum = 118;BA.debugLine="lblMem_Password.Text = Data.Get(\"mem_password\")";
_lblmem_password.setText(BA.ObjectToCharSequence(_data.Get((Object)("mem_password"))));
 //BA.debugLineNum = 119;BA.debugLine="lblMem_Memo.Text = Data.Get(\"mem_memo\")";
_lblmem_memo.setText(BA.ObjectToCharSequence(_data.Get((Object)("mem_memo"))));
 //BA.debugLineNum = 122;BA.debugLine="lblEdit.Tag = Data";
_lbledit.setTag((Object)(_data.getObject()));
 //BA.debugLineNum = 123;BA.debugLine="lblDelete.Tag = Data";
_lbldelete.setTag((Object)(_data.getObject()));
 //BA.debugLineNum = 124;BA.debugLine="Return p";
if (true) return _p;
 //BA.debugLineNum = 125;BA.debugLine="End Sub";
return null;
}
public Object  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 21;BA.debugLine="Public Sub Initialize As Object";
 //BA.debugLineNum = 22;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return null;
}
public void  _lbldelete_click() throws Exception{
ResumableSub_lblDelete_Click rsub = new ResumableSub_lblDelete_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_lblDelete_Click extends BA.ResumableSub {
public ResumableSub_lblDelete_Click(b4a.example.memberpage parent) {
this.parent = parent;
}
b4a.example.memberpage parent;
int _index = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _l = null;
anywheresoftware.b4a.objects.collections.Map _item = null;
Object _sf = null;
int _result = 0;
anywheresoftware.b4a.objects.StringUtils _su = null;
String _basicauth = "";
String _authinfo = "";
b4a.example.httpjob _job = null;
anywheresoftware.b4a.objects.collections.Map _m1 = null;
anywheresoftware.b4a.objects.collections.JSONParser.JSONGenerator _jg = null;
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _m = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 397;BA.debugLine="Log(\"lblDelete_Click==>\")";
parent.__c.LogImpl("43604481","lblDelete_Click==>",0);
 //BA.debugLineNum = 399;BA.debugLine="Dim Index As Int = clvData.GetItemFromView(Sender";
_index = parent._clvdata._getitemfromview((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba))));
 //BA.debugLineNum = 401;BA.debugLine="Dim l As B4XView";
_l = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 404;BA.debugLine="Dim l As B4XView";
_l = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 406;BA.debugLine="l = Sender";
_l = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba)));
 //BA.debugLineNum = 407;BA.debugLine="Dim Item As Map";
_item = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 408;BA.debugLine="Item.Initialize";
_item.Initialize();
 //BA.debugLineNum = 410;BA.debugLine="Item = l.Tag";
_item = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_l.getTag()));
 //BA.debugLineNum = 413;BA.debugLine="Dim sf As Object = xui.Msgbox2Async($\"刪除會員: ${Ite";
_sf = parent._xui.Msgbox2Async(ba,BA.ObjectToCharSequence(("刪除會員: "+parent.__c.SmartStringFormatter("",_item.Get((Object)("mem_name")))+"?")),BA.ObjectToCharSequence(""),"Yes","","No",(anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper(), (android.graphics.Bitmap)(parent.__c.Null)));
 //BA.debugLineNum = 415;BA.debugLine="Wait For (sf) Msgbox_Result (Result As Int)";
parent.__c.WaitFor("msgbox_result", ba, this, _sf);
this.state = 17;
return;
case 17:
//C
this.state = 1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 416;BA.debugLine="If Result = xui.DialogResponse_Positive Then";
if (true) break;

case 1:
//if
this.state = 16;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 418;BA.debugLine="Log(\"遠端刪除...\")";
parent.__c.LogImpl("43604502","遠端刪除...",0);
 //BA.debugLineNum = 419;BA.debugLine="Dim su As StringUtils";
_su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 420;BA.debugLine="Dim basicAuth,authInfo As String";
_basicauth = "";
_authinfo = "";
 //BA.debugLineNum = 421;BA.debugLine="Dim job As HttpJob";
_job = new b4a.example.httpjob();
 //BA.debugLineNum = 424;BA.debugLine="basicAuth = Starter.token";
_basicauth = parent._starter._token /*String*/ ;
 //BA.debugLineNum = 425;BA.debugLine="authInfo = su.EncodeBase64(basicAuth.GetBytes(\"U";
_authinfo = _su.EncodeBase64(_basicauth.getBytes("UTF8"));
 //BA.debugLineNum = 427;BA.debugLine="Log($\"basicAuth= Bearer ${su.EncodeBase64(basicA";
parent.__c.LogImpl("43604511",("basicAuth= Bearer "+parent.__c.SmartStringFormatter("",(Object)(_su.EncodeBase64(_basicauth.getBytes("UTF8"))))+""),0);
 //BA.debugLineNum = 429;BA.debugLine="Dim m1 As Map";
_m1 = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 430;BA.debugLine="m1.Initialize";
_m1.Initialize();
 //BA.debugLineNum = 431;BA.debugLine="m1.Put(\"action\",\"delete\")";
_m1.Put((Object)("action"),(Object)("delete"));
 //BA.debugLineNum = 432;BA.debugLine="m1.Put(\"mem_no\",Item.Get(\"mem_no\"))";
_m1.Put((Object)("mem_no"),_item.Get((Object)("mem_no")));
 //BA.debugLineNum = 434;BA.debugLine="Dim jg As JSONGenerator";
_jg = new anywheresoftware.b4a.objects.collections.JSONParser.JSONGenerator();
 //BA.debugLineNum = 435;BA.debugLine="jg.Initialize(m1)";
_jg.Initialize(_m1);
 //BA.debugLineNum = 436;BA.debugLine="jg.ToString";
_jg.ToString();
 //BA.debugLineNum = 438;BA.debugLine="job.Initialize(\"\",Me)";
_job._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 439;BA.debugLine="job.PostString($\"https://${Main.url}/ex02/ss_mem";
_job._poststring /*String*/ (("https://"+parent.__c.SmartStringFormatter("",(Object)(parent._main._url /*String*/ ))+"/ex02/ss_member"),("json="+parent.__c.SmartStringFormatter("",(Object)(_jg.ToString()))+""));
 //BA.debugLineNum = 440;BA.debugLine="job.GetRequest.SetHeader(\"Authorization\", \"Beare";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetHeader("Authorization","Bearer "+_authinfo);
 //BA.debugLineNum = 441;BA.debugLine="job.GetRequest.SetContentType(\"application/x-www";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetContentType("application/x-www-form-urlencoded");
 //BA.debugLineNum = 443;BA.debugLine="ProgressDialogShow(\"Connecting to server...\")";
parent.__c.ProgressDialogShow(ba,BA.ObjectToCharSequence("Connecting to server..."));
 //BA.debugLineNum = 444;BA.debugLine="Wait For (job) JobDone(job As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_job));
this.state = 18;
return;
case 18:
//C
this.state = 4;
_job = (b4a.example.httpjob) result[0];
;
 //BA.debugLineNum = 445;BA.debugLine="ProgressDialogHide";
parent.__c.ProgressDialogHide();
 //BA.debugLineNum = 446;BA.debugLine="Log(\"Result JobDone: \" & job.Success)";
parent.__c.LogImpl("43604530","Result JobDone: "+BA.ObjectToString(_job._success /*boolean*/ ),0);
 //BA.debugLineNum = 447;BA.debugLine="If job.Success Then";
if (true) break;

case 4:
//if
this.state = 15;
if (_job._success /*boolean*/ ) { 
this.state = 6;
}else {
this.state = 14;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 448;BA.debugLine="Log(\"Server回應 \"&job.GetString)";
parent.__c.LogImpl("43604532","Server回應 "+_job._getstring /*String*/ (),0);
 //BA.debugLineNum = 449;BA.debugLine="Dim parser As JSONParser";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 450;BA.debugLine="parser.Initialize(job.GetString)";
_parser.Initialize(_job._getstring /*String*/ ());
 //BA.debugLineNum = 451;BA.debugLine="Dim m As Map = parser.NextObject";
_m = new anywheresoftware.b4a.objects.collections.Map();
_m = _parser.NextObject();
 //BA.debugLineNum = 452;BA.debugLine="If m.Get(\"success\") = \"0\" Then";
if (true) break;

case 7:
//if
this.state = 12;
if ((_m.Get((Object)("success"))).equals((Object)("0"))) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 453;BA.debugLine="Log(m.Get(\"message\"))";
parent.__c.LogImpl("43604537",BA.ObjectToString(_m.Get((Object)("message"))),0);
 //BA.debugLineNum = 454;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast";
parent._function01._showtoast /*String*/ (ba,parent._b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._toast /*b4a.example.bctoast*/ ,parent._root,BA.ObjectToString(_m.Get((Object)("message"))));
 //BA.debugLineNum = 456;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 458;BA.debugLine="Log(m.Get(\"message\"))";
parent.__c.LogImpl("43604542",BA.ObjectToString(_m.Get((Object)("message"))),0);
 if (true) break;

case 12:
//C
this.state = 15;
;
 if (true) break;

case 14:
//C
this.state = 15;
 //BA.debugLineNum = 461;BA.debugLine="Log(job.ErrorMessage)";
parent.__c.LogImpl("43604545",_job._errormessage /*String*/ ,0);
 //BA.debugLineNum = 462;BA.debugLine="xui.MsgboxAsync(job.ErrorMessage, \"Error\")";
parent._xui.MsgboxAsync(ba,BA.ObjectToCharSequence(_job._errormessage /*String*/ ),BA.ObjectToCharSequence("Error"));
 //BA.debugLineNum = 464;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 15:
//C
this.state = 16;
;
 //BA.debugLineNum = 467;BA.debugLine="Log(\"本地刪除...\")";
parent.__c.LogImpl("43604551","本地刪除...",0);
 //BA.debugLineNum = 468;BA.debugLine="clvData.RemoveAt(Index)";
parent._clvdata._removeat(_index);
 //BA.debugLineNum = 469;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast ,";
parent._function01._showtoast /*String*/ (ba,parent._b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._toast /*b4a.example.bctoast*/ ,parent._root,"刪除成功!!");
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 474;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _msgbox_result(int _result) throws Exception{
}
public void  _lbledit_click() throws Exception{
ResumableSub_lblEdit_Click rsub = new ResumableSub_lblEdit_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_lblEdit_Click extends BA.ResumableSub {
public ResumableSub_lblEdit_Click(b4a.example.memberpage parent) {
this.parent = parent;
}
b4a.example.memberpage parent;
int _index = 0;
anywheresoftware.b4a.objects.B4XViewWrapper _pnl = null;
anywheresoftware.b4a.objects.B4XViewWrapper _l = null;
anywheresoftware.b4a.objects.collections.Map _item = null;
int _result = 0;
anywheresoftware.b4a.objects.StringUtils _su = null;
String _basicauth = "";
String _authinfo = "";
b4a.example.httpjob _job = null;
anywheresoftware.b4a.objects.collections.Map _m1 = null;
anywheresoftware.b4a.objects.collections.JSONParser.JSONGenerator _jg = null;
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _m = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 283;BA.debugLine="Log(\"lblEdit_Click==>\")";
parent.__c.LogImpl("43538945","lblEdit_Click==>",0);
 //BA.debugLineNum = 288;BA.debugLine="Dim Index As Int = clvData.GetItemFromView(Sender";
_index = parent._clvdata._getitemfromview((anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba))));
 //BA.debugLineNum = 289;BA.debugLine="Dim pnl As B4XView = clvData.GetPanel(Index)";
_pnl = new anywheresoftware.b4a.objects.B4XViewWrapper();
_pnl = parent._clvdata._getpanel(_index);
 //BA.debugLineNum = 290;BA.debugLine="Dim l As B4XView";
_l = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 292;BA.debugLine="l = Sender";
_l = (anywheresoftware.b4a.objects.B4XViewWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper(), (java.lang.Object)(parent.__c.Sender(ba)));
 //BA.debugLineNum = 293;BA.debugLine="Dim Item As Map";
_item = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 294;BA.debugLine="Item.Initialize";
_item.Initialize();
 //BA.debugLineNum = 295;BA.debugLine="Item = l.Tag";
_item = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_l.getTag()));
 //BA.debugLineNum = 296;BA.debugLine="Item.Put(\"mem_oldno\",Item.Get(\"mem_no\"))";
_item.Put((Object)("mem_oldno"),_item.Get((Object)("mem_no")));
 //BA.debugLineNum = 298;BA.debugLine="PrefDialog.Title = \"會員資料-修改\"";
parent._prefdialog._settitle /*Object*/ ((Object)("會員資料-修改"));
 //BA.debugLineNum = 299;BA.debugLine="PrefDialog.LoadFromJson(File.ReadString(File.DirA";
parent._prefdialog._loadfromjson /*String*/ (parent.__c.File.ReadString(parent.__c.File.getDirAssets(),"template.json"));
 //BA.debugLineNum = 301;BA.debugLine="Wait For (PrefDialog.ShowDialog(Item, \"OK\", \"CANC";
parent.__c.WaitFor("complete", ba, this, parent._prefdialog._showdialog /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_item,(Object)("OK"),(Object)("CANCEL")));
this.state = 27;
return;
case 27:
//C
this.state = 1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 302;BA.debugLine="If Result = xui.DialogResponse_Positive Then";
if (true) break;

case 1:
//if
this.state = 26;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 303;BA.debugLine="Log(\"遠端修改...\")";
parent.__c.LogImpl("43538965","遠端修改...",0);
 //BA.debugLineNum = 304;BA.debugLine="Dim su As StringUtils";
_su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 305;BA.debugLine="Dim basicAuth,authInfo As String";
_basicauth = "";
_authinfo = "";
 //BA.debugLineNum = 306;BA.debugLine="Dim job As HttpJob";
_job = new b4a.example.httpjob();
 //BA.debugLineNum = 309;BA.debugLine="basicAuth =  Starter.token";
_basicauth = parent._starter._token /*String*/ ;
 //BA.debugLineNum = 310;BA.debugLine="authInfo = su.EncodeBase64(basicAuth.GetBytes(\"U";
_authinfo = _su.EncodeBase64(_basicauth.getBytes("UTF8"));
 //BA.debugLineNum = 312;BA.debugLine="Log($\"basicAuth= Bearer ${su.EncodeBase64(basicA";
parent.__c.LogImpl("43538974",("basicAuth= Bearer "+parent.__c.SmartStringFormatter("",(Object)(_su.EncodeBase64(_basicauth.getBytes("UTF8"))))+""),0);
 //BA.debugLineNum = 314;BA.debugLine="Dim m1 As Map";
_m1 = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 315;BA.debugLine="m1.Initialize";
_m1.Initialize();
 //BA.debugLineNum = 316;BA.debugLine="m1.Put(\"action\",\"update\")";
_m1.Put((Object)("action"),(Object)("update"));
 //BA.debugLineNum = 317;BA.debugLine="m1.Put(\"mem_no\",Item.Get(\"mem_no\"))";
_m1.Put((Object)("mem_no"),_item.Get((Object)("mem_no")));
 //BA.debugLineNum = 318;BA.debugLine="m1.Put(\"mem_name\",Item.Get(\"mem_name\"))";
_m1.Put((Object)("mem_name"),_item.Get((Object)("mem_name")));
 //BA.debugLineNum = 319;BA.debugLine="m1.Put(\"mem_password\",Item.Get(\"mem_password\"))";
_m1.Put((Object)("mem_password"),_item.Get((Object)("mem_password")));
 //BA.debugLineNum = 320;BA.debugLine="m1.Put(\"mem_memo\",Item.Get(\"mem_memo\"))";
_m1.Put((Object)("mem_memo"),_item.Get((Object)("mem_memo")));
 //BA.debugLineNum = 321;BA.debugLine="m1.Put(\"mem_oldno\",Item.Get(\"mem_oldno\"))";
_m1.Put((Object)("mem_oldno"),_item.Get((Object)("mem_oldno")));
 //BA.debugLineNum = 323;BA.debugLine="Dim jg As JSONGenerator";
_jg = new anywheresoftware.b4a.objects.collections.JSONParser.JSONGenerator();
 //BA.debugLineNum = 324;BA.debugLine="jg.Initialize(m1)";
_jg.Initialize(_m1);
 //BA.debugLineNum = 325;BA.debugLine="jg.ToString";
_jg.ToString();
 //BA.debugLineNum = 327;BA.debugLine="job.Initialize(\"\",Me)";
_job._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 328;BA.debugLine="job.PostString($\"https://${Main.url}/ex02/ss_mem";
_job._poststring /*String*/ (("https://"+parent.__c.SmartStringFormatter("",(Object)(parent._main._url /*String*/ ))+"/ex02/ss_member"),("json="+parent.__c.SmartStringFormatter("",(Object)(_jg.ToString()))+""));
 //BA.debugLineNum = 329;BA.debugLine="job.GetRequest.SetHeader(\"Authorization\", \"Beare";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetHeader("Authorization","Bearer "+_authinfo);
 //BA.debugLineNum = 330;BA.debugLine="job.GetRequest.SetContentType(\"application/x-www";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetContentType("application/x-www-form-urlencoded");
 //BA.debugLineNum = 332;BA.debugLine="ProgressDialogShow(\"Connecting to server...\")";
parent.__c.ProgressDialogShow(ba,BA.ObjectToCharSequence("Connecting to server..."));
 //BA.debugLineNum = 333;BA.debugLine="Wait For (job) JobDone(job As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_job));
this.state = 28;
return;
case 28:
//C
this.state = 4;
_job = (b4a.example.httpjob) result[0];
;
 //BA.debugLineNum = 334;BA.debugLine="ProgressDialogHide";
parent.__c.ProgressDialogHide();
 //BA.debugLineNum = 335;BA.debugLine="Log(\"Result JobDone: \" & job.Success)";
parent.__c.LogImpl("43538997","Result JobDone: "+BA.ObjectToString(_job._success /*boolean*/ ),0);
 //BA.debugLineNum = 336;BA.debugLine="If job.Success Then";
if (true) break;

case 4:
//if
this.state = 15;
if (_job._success /*boolean*/ ) { 
this.state = 6;
}else {
this.state = 14;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 337;BA.debugLine="Log(\"Server回應 \"&job.GetString)";
parent.__c.LogImpl("43538999","Server回應 "+_job._getstring /*String*/ (),0);
 //BA.debugLineNum = 338;BA.debugLine="Dim parser As JSONParser";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 339;BA.debugLine="parser.Initialize(job.GetString)";
_parser.Initialize(_job._getstring /*String*/ ());
 //BA.debugLineNum = 340;BA.debugLine="Dim m As Map = parser.NextObject";
_m = new anywheresoftware.b4a.objects.collections.Map();
_m = _parser.NextObject();
 //BA.debugLineNum = 341;BA.debugLine="If m.Get(\"success\") = \"0\" Then";
if (true) break;

case 7:
//if
this.state = 12;
if ((_m.Get((Object)("success"))).equals((Object)("0"))) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 342;BA.debugLine="Log(m.Get(\"message\"))";
parent.__c.LogImpl("43539004",BA.ObjectToString(_m.Get((Object)("message"))),0);
 //BA.debugLineNum = 343;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast";
parent._function01._showtoast /*String*/ (ba,parent._b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._toast /*b4a.example.bctoast*/ ,parent._root,BA.ObjectToString(_m.Get((Object)("message"))));
 //BA.debugLineNum = 345;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 347;BA.debugLine="Log(m.Get(\"message\"))";
parent.__c.LogImpl("43539009",BA.ObjectToString(_m.Get((Object)("message"))),0);
 if (true) break;

case 12:
//C
this.state = 15;
;
 if (true) break;

case 14:
//C
this.state = 15;
 //BA.debugLineNum = 350;BA.debugLine="Log(job.ErrorMessage)";
parent.__c.LogImpl("43539012",_job._errormessage /*String*/ ,0);
 //BA.debugLineNum = 351;BA.debugLine="xui.MsgboxAsync(job.ErrorMessage, \"Error\")";
parent._xui.MsgboxAsync(ba,BA.ObjectToCharSequence(_job._errormessage /*String*/ ),BA.ObjectToCharSequence("Error"));
 //BA.debugLineNum = 353;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 15:
//C
this.state = 16;
;
 //BA.debugLineNum = 356;BA.debugLine="Log(\"本地修改...\")";
parent.__c.LogImpl("43539018","本地修改...",0);
 //BA.debugLineNum = 365;BA.debugLine="If pnl.NumberOfViews > 0 Then";
if (true) break;

case 16:
//if
this.state = 25;
if (_pnl.getNumberOfViews()>0) { 
this.state = 18;
}if (true) break;

case 18:
//C
this.state = 19;
 //BA.debugLineNum = 372;BA.debugLine="Try";
if (true) break;

case 19:
//try
this.state = 24;
this.catchState = 23;
this.state = 21;
if (true) break;

case 21:
//C
this.state = 24;
this.catchState = 23;
 //BA.debugLineNum = 373;BA.debugLine="dd.GetViewByName(pnl, \"lblmem_no\").Text = m1.G";
parent._dd._getviewbyname /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_pnl,"lblmem_no").setText(BA.ObjectToCharSequence(_m1.Get((Object)("mem_no"))));
 //BA.debugLineNum = 374;BA.debugLine="dd.GetViewByName(pnl, \"lblmem_name\").Text = m1";
parent._dd._getviewbyname /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_pnl,"lblmem_name").setText(BA.ObjectToCharSequence(_m1.Get((Object)("mem_name"))));
 //BA.debugLineNum = 375;BA.debugLine="dd.GetViewByName(pnl, \"lblmem_password\").Text";
parent._dd._getviewbyname /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_pnl,"lblmem_password").setText(BA.ObjectToCharSequence(_m1.Get((Object)("mem_password"))));
 //BA.debugLineNum = 376;BA.debugLine="dd.GetViewByName(pnl, \"lblmem_memo\").Text = m1";
parent._dd._getviewbyname /*anywheresoftware.b4a.objects.B4XViewWrapper*/ (_pnl,"lblmem_memo").setText(BA.ObjectToCharSequence(_m1.Get((Object)("mem_memo"))));
 //BA.debugLineNum = 378;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast";
parent._function01._showtoast /*String*/ (ba,parent._b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._toast /*b4a.example.bctoast*/ ,parent._root,"修改成功!!");
 if (true) break;

case 23:
//C
this.state = 24;
this.catchState = 0;
 //BA.debugLineNum = 380;BA.debugLine="Log(\"err: \"&LastException)";
parent.__c.LogImpl("43539042","err: "+BA.ObjectToString(parent.__c.LastException(ba)),0);
 //BA.debugLineNum = 381;BA.debugLine="xui.MsgboxAsync(LastException, \"Error\")";
parent._xui.MsgboxAsync(ba,BA.ObjectToCharSequence(parent.__c.LastException(ba).getObject()),BA.ObjectToCharSequence("Error"));
 if (true) break;
if (true) break;

case 24:
//C
this.state = 25;
this.catchState = 0;
;
 if (true) break;

case 25:
//C
this.state = 26;
;
 if (true) break;

case 26:
//C
this.state = -1;
;
 //BA.debugLineNum = 392;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public void  _querydata() throws Exception{
ResumableSub_QueryData rsub = new ResumableSub_QueryData(this);
rsub.resume(ba, null);
}
public static class ResumableSub_QueryData extends BA.ResumableSub {
public ResumableSub_QueryData(b4a.example.memberpage parent) {
this.parent = parent;
}
b4a.example.memberpage parent;
anywheresoftware.b4a.objects.StringUtils _su = null;
String _basicauth = "";
String _authinfo = "";
b4a.example.httpjob _job = null;
anywheresoftware.b4a.objects.collections.Map _m1 = null;
anywheresoftware.b4a.objects.collections.JSONParser.JSONGenerator _jg = null;
anywheresoftware.b4a.objects.collections.JSONParser _parser = null;
anywheresoftware.b4a.objects.collections.Map _m = null;
anywheresoftware.b4a.objects.collections.List _udata = null;
int _u = 0;
anywheresoftware.b4a.objects.collections.Map _mdata = null;
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
int step39;
int limit39;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 129;BA.debugLine="clvData.Clear";
parent._clvdata._clear();
 //BA.debugLineNum = 132;BA.debugLine="Log(\"查詢....\")";
parent.__c.LogImpl("43407877","查詢....",0);
 //BA.debugLineNum = 133;BA.debugLine="Dim su As StringUtils";
_su = new anywheresoftware.b4a.objects.StringUtils();
 //BA.debugLineNum = 134;BA.debugLine="Dim basicAuth,authInfo As String";
_basicauth = "";
_authinfo = "";
 //BA.debugLineNum = 135;BA.debugLine="Dim job As HttpJob";
_job = new b4a.example.httpjob();
 //BA.debugLineNum = 137;BA.debugLine="basicAuth = Starter.token";
_basicauth = parent._starter._token /*String*/ ;
 //BA.debugLineNum = 138;BA.debugLine="authInfo = su.EncodeBase64(basicAuth.GetBytes(\"UT";
_authinfo = _su.EncodeBase64(_basicauth.getBytes("UTF8"));
 //BA.debugLineNum = 140;BA.debugLine="Log($\"basicAuth= Bearer ${su.EncodeBase64(basicAu";
parent.__c.LogImpl("43407885",("basicAuth= Bearer "+parent.__c.SmartStringFormatter("",(Object)(_su.EncodeBase64(_basicauth.getBytes("UTF8"))))+""),0);
 //BA.debugLineNum = 142;BA.debugLine="Dim m1 As Map";
_m1 = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 144;BA.debugLine="m1.Initialize";
_m1.Initialize();
 //BA.debugLineNum = 145;BA.debugLine="m1.Put(\"action\",\"query\")";
_m1.Put((Object)("action"),(Object)("query"));
 //BA.debugLineNum = 146;BA.debugLine="m1.Put(\"mem_no\",\"\")";
_m1.Put((Object)("mem_no"),(Object)(""));
 //BA.debugLineNum = 147;BA.debugLine="m1.Put(\"mem_name\",\"\")";
_m1.Put((Object)("mem_name"),(Object)(""));
 //BA.debugLineNum = 149;BA.debugLine="Dim jg As JSONGenerator";
_jg = new anywheresoftware.b4a.objects.collections.JSONParser.JSONGenerator();
 //BA.debugLineNum = 151;BA.debugLine="jg.Initialize(m1)";
_jg.Initialize(_m1);
 //BA.debugLineNum = 152;BA.debugLine="jg.ToString";
_jg.ToString();
 //BA.debugLineNum = 154;BA.debugLine="job.Initialize(\"\",Me)";
_job._initialize /*String*/ (ba,"",parent);
 //BA.debugLineNum = 155;BA.debugLine="job.PostString($\"https://${Main.url}/ex02/ss_memb";
_job._poststring /*String*/ (("https://"+parent.__c.SmartStringFormatter("",(Object)(parent._main._url /*String*/ ))+"/ex02/ss_member"),("json="+parent.__c.SmartStringFormatter("",(Object)(_jg.ToString()))+""));
 //BA.debugLineNum = 156;BA.debugLine="job.GetRequest.SetHeader(\"Authorization\", \"Bearer";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetHeader("Authorization","Bearer "+_authinfo);
 //BA.debugLineNum = 157;BA.debugLine="job.GetRequest.SetContentType(\"application/x-www-";
_job._getrequest /*anywheresoftware.b4h.okhttp.OkHttpClientWrapper.OkHttpRequest*/ ().SetContentType("application/x-www-form-urlencoded");
 //BA.debugLineNum = 159;BA.debugLine="ProgressDialogShow(\"Connecting to server...\")";
parent.__c.ProgressDialogShow(ba,BA.ObjectToCharSequence("Connecting to server..."));
 //BA.debugLineNum = 160;BA.debugLine="Wait For (job) JobDone(job As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_job));
this.state = 17;
return;
case 17:
//C
this.state = 1;
_job = (b4a.example.httpjob) result[0];
;
 //BA.debugLineNum = 161;BA.debugLine="ProgressDialogHide";
parent.__c.ProgressDialogHide();
 //BA.debugLineNum = 162;BA.debugLine="Log(\"Result JobDone: \" & job.Success)";
parent.__c.LogImpl("43407907","Result JobDone: "+BA.ObjectToString(_job._success /*boolean*/ ),0);
 //BA.debugLineNum = 163;BA.debugLine="If job.Success Then";
if (true) break;

case 1:
//if
this.state = 16;
if (_job._success /*boolean*/ ) { 
this.state = 3;
}else {
this.state = 15;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 164;BA.debugLine="Log(\"Server回應 \"&job.GetString)";
parent.__c.LogImpl("43407909","Server回應 "+_job._getstring /*String*/ (),0);
 //BA.debugLineNum = 165;BA.debugLine="Dim parser As JSONParser";
_parser = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 166;BA.debugLine="parser.Initialize(job.GetString)";
_parser.Initialize(_job._getstring /*String*/ ());
 //BA.debugLineNum = 167;BA.debugLine="Dim m As Map = parser.NextObject";
_m = new anywheresoftware.b4a.objects.collections.Map();
_m = _parser.NextObject();
 //BA.debugLineNum = 169;BA.debugLine="If m.Get(\"success\") = \"0\" Then";
if (true) break;

case 4:
//if
this.state = 13;
if ((_m.Get((Object)("success"))).equals((Object)("0"))) { 
this.state = 6;
}else {
this.state = 8;
}if (true) break;

case 6:
//C
this.state = 13;
 //BA.debugLineNum = 170;BA.debugLine="Log(m.Get(\"message\"))";
parent.__c.LogImpl("43407915",BA.ObjectToString(_m.Get((Object)("message"))),0);
 //BA.debugLineNum = 171;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast ,";
parent._function01._showtoast /*String*/ (ba,parent._b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._toast /*b4a.example.bctoast*/ ,parent._root,BA.ObjectToString(_m.Get((Object)("message"))));
 //BA.debugLineNum = 173;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 8:
//C
this.state = 9;
 //BA.debugLineNum = 175;BA.debugLine="Log(m.Get(\"message\"))";
parent.__c.LogImpl("43407920",BA.ObjectToString(_m.Get((Object)("message"))),0);
 //BA.debugLineNum = 177;BA.debugLine="Dim udata As List";
_udata = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 178;BA.debugLine="udata.Initialize";
_udata.Initialize();
 //BA.debugLineNum = 179;BA.debugLine="udata = m.Get(\"udata\")";
_udata = (anywheresoftware.b4a.objects.collections.List) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.List(), (java.util.List)(_m.Get((Object)("udata"))));
 //BA.debugLineNum = 181;BA.debugLine="For u=0 To udata.Size -1";
if (true) break;

case 9:
//for
this.state = 12;
step39 = 1;
limit39 = (int) (_udata.getSize()-1);
_u = (int) (0) ;
this.state = 18;
if (true) break;

case 18:
//C
this.state = 12;
if ((step39 > 0 && _u <= limit39) || (step39 < 0 && _u >= limit39)) this.state = 11;
if (true) break;

case 19:
//C
this.state = 18;
_u = ((int)(0 + _u + step39)) ;
if (true) break;

case 11:
//C
this.state = 19;
 //BA.debugLineNum = 182;BA.debugLine="Dim mdata As Map";
_mdata = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 183;BA.debugLine="mdata.Initialize";
_mdata.Initialize();
 //BA.debugLineNum = 184;BA.debugLine="mdata = udata.Get(u)";
_mdata = (anywheresoftware.b4a.objects.collections.Map) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.Map(), (java.util.Map)(_udata.Get(_u)));
 //BA.debugLineNum = 186;BA.debugLine="Dim p As B4XView = CreateCard(mdata)";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = parent._createcard(_mdata);
 //BA.debugLineNum = 187;BA.debugLine="clvData.Add(p, mdata)";
parent._clvdata._add(_p,(Object)(_mdata.getObject()));
 //BA.debugLineNum = 189;BA.debugLine="Log(\"u= \"&u)";
parent.__c.LogImpl("43407934","u= "+BA.NumberToString(_u),0);
 if (true) break;
if (true) break;

case 12:
//C
this.state = 13;
;
 //BA.debugLineNum = 192;BA.debugLine="Function01.ShowToast (B4XPages.MainPage.toast ,";
parent._function01._showtoast /*String*/ (ba,parent._b4xpages._mainpage /*b4a.example.b4xmainpage*/ (ba)._toast /*b4a.example.bctoast*/ ,parent._root,"查詢完畢!!");
 if (true) break;

case 13:
//C
this.state = 16;
;
 if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 196;BA.debugLine="Log(job.ErrorMessage)";
parent.__c.LogImpl("43407941",_job._errormessage /*String*/ ,0);
 //BA.debugLineNum = 197;BA.debugLine="xui.MsgboxAsync(job.ErrorMessage, \"Error\")";
parent._xui.MsgboxAsync(ba,BA.ObjectToCharSequence(_job._errormessage /*String*/ ),BA.ObjectToCharSequence("Error"));
 //BA.debugLineNum = 199;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 202;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
