package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class udpbroadcast extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.udpbroadcast", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.udpbroadcast.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.SocketWrapper.UDPSocket _udpsock = null;
public int _port = 0;
public anywheresoftware.b4a.objects.Timer _timer1 = null;
public b4j.example.main _main = null;
public b4j.example.b4xpages _b4xpages = null;
public b4j.example.b4xcollections _b4xcollections = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Private udpsock As UDPSocket";
_udpsock = new anywheresoftware.b4a.objects.SocketWrapper.UDPSocket();
 //BA.debugLineNum = 5;BA.debugLine="Public const port As Int = 9000";
_port = (int) (9000);
 //BA.debugLineNum = 7;BA.debugLine="Private timer1 As Timer";
_timer1 = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 8;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 11;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 12;BA.debugLine="udpsock.Initialize(\"udpsock\", 0, 0)";
_udpsock.Initialize(ba,"udpsock",(int) (0),(int) (0));
 //BA.debugLineNum = 14;BA.debugLine="timer1.Initialize(\"timer1\",10000)";
_timer1.Initialize(ba,"timer1",(long) (10000));
 //BA.debugLineNum = 15;BA.debugLine="timer1.Enabled =True";
_timer1.setEnabled(__c.True);
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _test() throws Exception{
ResumableSub_test rsub = new ResumableSub_test(this);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_test extends BA.ResumableSub {
public ResumableSub_test(b4j.example.udpbroadcast parent) {
this.parent = parent;
}
b4j.example.udpbroadcast parent;
byte[] _data = null;
anywheresoftware.b4a.objects.SocketWrapper.UDPSocket.UDPPacket _packet = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = -1;
 //BA.debugLineNum = 30;BA.debugLine="LogColor(\"對所有人廣播中:\"&udpsock.GetBroadcastAddress,";
parent.__c.LogImpl("210223618","對所有人廣播中:"+parent._udpsock.GetBroadcastAddress(),((int)0xffff0000));
 //BA.debugLineNum = 35;BA.debugLine="Dim data() As Byte = \"PCTools\".GetBytes(\"UTF8\")";
_data = "PCTools".getBytes("UTF8");
 //BA.debugLineNum = 37;BA.debugLine="Dim packet As UDPPacket";
_packet = new anywheresoftware.b4a.objects.SocketWrapper.UDPSocket.UDPPacket();
 //BA.debugLineNum = 38;BA.debugLine="packet.Initialize(data, udpsock.GetBroadcastAddre";
_packet.Initialize(_data,parent._udpsock.GetBroadcastAddress(),parent._port);
 //BA.debugLineNum = 40;BA.debugLine="udpsock.Send(packet)";
parent._udpsock.Send(_packet);
 //BA.debugLineNum = 42;BA.debugLine="Return True";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(parent.__c.True));return;};
 //BA.debugLineNum = 43;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _timer1_tick() throws Exception{
ResumableSub_timer1_Tick rsub = new ResumableSub_timer1_Tick(this);
rsub.resume(ba, null);
}
public static class ResumableSub_timer1_Tick extends BA.ResumableSub {
public ResumableSub_timer1_Tick(b4j.example.udpbroadcast parent) {
this.parent = parent;
}
b4j.example.udpbroadcast parent;
boolean _result = false;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = -1;
 //BA.debugLineNum = 23;BA.debugLine="Wait For (test) Complete (Result As Boolean)";
parent.__c.WaitFor("complete", ba, this, parent._test());
this.state = 1;
return;
case 1:
//C
this.state = -1;
_result = (boolean) result[0];
;
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(boolean _result) throws Exception{
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
