package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class b4xmainpage extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.b4xmainpage", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.b4xmainpage.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4j.objects.JFX _fx = null;
public anywheresoftware.b4j.objects.SystemTrayWrapper _tray = null;
public anywheresoftware.b4j.objects.SystemTrayWrapper.TrayIconWrapper _icon1 = null;
public b4j.example.connector _udp1 = null;
public b4j.example.commandhandler _handler = null;
public b4j.example.udpbroadcast _udp2 = null;
public long _lastping = 0L;
public anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper _blueimage = null;
public anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper _greenimage = null;
public b4j.example.main _main = null;
public b4j.example.b4xpages _b4xpages = null;
public b4j.example.b4xcollections _b4xcollections = null;
public static class _remotecommand{
public boolean IsInitialized;
public int Command;
public String Method;
public Object[] Args;
public void Initialize() {
IsInitialized = true;
Command = 0;
Method = "";
Args = new Object[0];
{
int d0 = Args.length;
for (int i0 = 0;i0 < d0;i0++) {
Args[i0] = new Object();
}
}
;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
b4j.example.b4xmainpage _mainp = null;
String[] _menuitems = null;
 //BA.debugLineNum = 43;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 44;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 45;BA.debugLine="Root.LoadLayout(\"MainPage\")";
_root.LoadLayout("MainPage",ba);
 //BA.debugLineNum = 47;BA.debugLine="Dim mainP As B4XMainPage = B4XPages.GetPage(\"Main";
_mainp = (b4j.example.b4xmainpage)(_b4xpages._getpage /*Object*/ ("MainPage"));
 //BA.debugLineNum = 49;BA.debugLine="B4XPages.SetTitle(mainP,\"PC小幫手 v2022\")";
_b4xpages._settitle /*String*/ ((Object)(_mainp),(Object)("PC小幫手 v2022"));
 //BA.debugLineNum = 56;BA.debugLine="tray.Initialize";
_tray.Initialize();
 //BA.debugLineNum = 57;BA.debugLine="BlueImage = fx.LoadImage(File.DirAssets, \"Blue.pn";
_blueimage = _fx.LoadImage(__c.File.getDirAssets(),"Blue.png");
 //BA.debugLineNum = 58;BA.debugLine="GreenImage = fx.LoadImage(File.DirAssets, \"Green.";
_greenimage = _fx.LoadImage(__c.File.getDirAssets(),"Green.png");
 //BA.debugLineNum = 60;BA.debugLine="Dim MenuItems() As String = Array As String(\"Blue";
_menuitems = new String[]{"Blue","Show IP","-","Exit"};
 //BA.debugLineNum = 61;BA.debugLine="icon1.Initialize(\"icon1\", BlueImage, MenuItems)";
_icon1.Initialize(ba,"icon1",(javafx.scene.image.Image)(_blueimage.getObject()),anywheresoftware.b4a.keywords.Common.ArrayToList(_menuitems));
 //BA.debugLineNum = 62;BA.debugLine="icon1.ToolTip = \"雙擊顯示表單. 右鍵顯示選單.\"";
_icon1.setToolTip("雙擊顯示表單. 右鍵顯示選單.");
 //BA.debugLineNum = 63;BA.debugLine="tray.AddTrayIcon(icon1)";
_tray.AddTrayIcon(_icon1);
 //BA.debugLineNum = 65;BA.debugLine="ShowNotification($\"IP address= ${udp1.MyIP} 	port";
_shownotification(("IP address= "+__c.SmartStringFormatter("",(Object)(_udp1._myip /*String*/ ))+"\n"+"	port: "+__c.SmartStringFormatter("",(Object)(_udp1._port /*int*/ ))+""));
 //BA.debugLineNum = 69;BA.debugLine="End Sub";
return "";
}
public String  _button1_click() throws Exception{
 //BA.debugLineNum = 76;BA.debugLine="Private Sub Button1_Click";
 //BA.debugLineNum = 77;BA.debugLine="xui.MsgboxAsync(\"Hello world!\", \"B4X\")";
_xui.MsgboxAsync(ba,"Hello world!","B4X");
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private Root As B4XView";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 12;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 13;BA.debugLine="Private tray As SystemTray";
_tray = new anywheresoftware.b4j.objects.SystemTrayWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private icon1 As TrayIcon";
_icon1 = new anywheresoftware.b4j.objects.SystemTrayWrapper.TrayIconWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Type RemoteCommand (Command As Int, Method As Str";
;
 //BA.debugLineNum = 17;BA.debugLine="Private udp1 As Connector";
_udp1 = new b4j.example.connector();
 //BA.debugLineNum = 18;BA.debugLine="Public Handler As CommandHandler";
_handler = new b4j.example.commandhandler();
 //BA.debugLineNum = 20;BA.debugLine="Private udp2 As UDPBroadCast	'UDP廣播";
_udp2 = new b4j.example.udpbroadcast();
 //BA.debugLineNum = 25;BA.debugLine="Public lastping As Long = 0";
_lastping = (long) (0);
 //BA.debugLineNum = 27;BA.debugLine="Private BlueImage, GreenImage As Image";
_blueimage = new anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper();
_greenimage = new anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper();
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return "";
}
public String  _icon1_doubleclick() throws Exception{
 //BA.debugLineNum = 81;BA.debugLine="Sub Icon1_DoubleClick";
 //BA.debugLineNum = 82;BA.debugLine="Log(\"Icon1_DoubleClick==>\")";
__c.LogImpl("29371649","Icon1_DoubleClick==>",0);
 //BA.debugLineNum = 84;BA.debugLine="Log(\"雙擊顯示視窗...\")";
__c.LogImpl("29371651","雙擊顯示視窗...",0);
 //BA.debugLineNum = 86;BA.debugLine="B4XPages.ShowPage(\"MainPage\")";
_b4xpages._showpage /*String*/ ("MainPage");
 //BA.debugLineNum = 87;BA.debugLine="End Sub";
return "";
}
public String  _icon1_menuclick(String _text) throws Exception{
 //BA.debugLineNum = 89;BA.debugLine="Sub Icon1_MenuClick (Text As String)";
 //BA.debugLineNum = 90;BA.debugLine="Select Text";
switch (BA.switchObjectToInt(_text,"Blue","Show IP","Exit")) {
case 0: {
 //BA.debugLineNum = 92;BA.debugLine="icon1.SetImage(GreenImage)";
_icon1.SetImage((javafx.scene.image.Image)(_greenimage.getObject()));
 break; }
case 1: {
 //BA.debugLineNum = 94;BA.debugLine="udp1.ShowIp";
_udp1._showip /*String*/ ();
 break; }
case 2: {
 //BA.debugLineNum = 96;BA.debugLine="ExitApplication";
__c.ExitApplication();
 break; }
}
;
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 32;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 36;BA.debugLine="udp1.Initialize		'UDP類別";
_udp1._initialize /*String*/ (ba);
 //BA.debugLineNum = 37;BA.debugLine="udp2.Initialize";
_udp2._initialize /*String*/ (ba);
 //BA.debugLineNum = 39;BA.debugLine="Handler.Initialize			'AWTRobot類別";
_handler._initialize /*String*/ (ba);
 //BA.debugLineNum = 40;BA.debugLine="End Sub";
return "";
}
public String  _shownotification(String _message) throws Exception{
anywheresoftware.b4j.object.JavaObject _jo = null;
 //BA.debugLineNum = 100;BA.debugLine="Public Sub ShowNotification(Message As String)";
 //BA.debugLineNum = 102;BA.debugLine="Dim jo As JavaObject = icon1";
_jo = new anywheresoftware.b4j.object.JavaObject();
_jo = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_icon1.getObject()));
 //BA.debugLineNum = 103;BA.debugLine="jo.RunMethod(\"displayMessage\",Array As Object(Mes";
_jo.RunMethod("displayMessage",new Object[]{(Object)(_message),(Object)(""),(Object)("NONE")});
 //BA.debugLineNum = 105;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
